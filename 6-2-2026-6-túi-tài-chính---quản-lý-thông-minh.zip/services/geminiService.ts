
import { GoogleGenAI } from "@google/genai";
import type { Jar } from '../types';

// Use the API key directly from process.env.API_KEY as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getFinancialAdvice(situation: string, currentJars: Jar[]): Promise<string> {
    // Fix: Updated to 'gemini-3-pro-preview' for advanced financial reasoning and recommendations.
    const model = 'gemini-3-pro-preview';

    const currentAllocation = currentJars.map(j => `${j.name}: ${j.percentage}%`).join(', ');

    const systemInstruction = `Bạn là một chuyên gia tư vấn tài chính thân thiện, chuyên về phương pháp quản lý tiền bạc "6 chiếc hũ" (6 Jars). Nhiệm vụ của bạn là đưa ra những lời khuyên thực tế, hữu ích để giúp người dùng điều chỉnh tỷ lệ phân bổ cho các hũ dựa trên tình hình cá nhân của họ.
    
    Các hũ bao gồm:
    1. Chi phí thiết yếu (NEC): Nhu cầu cơ bản.
    2. Tự do tài chính (FFA): Đầu tư tạo thu nhập thụ động.
    3. Tiết kiệm dài hạn (LTS): Cho các mục tiêu lớn.
    4. Giáo dục (EDU): Phát triển bản thân.
    5. Hưởng thụ (PLAY): Giải trí, tự thưởng.
    6. Cho đi (GIVE): Từ thiện, giúp đỡ người khác.

    Khi đưa ra lời khuyên:
    - Luôn đảm bảo tổng tỷ lệ phần trăm của 6 hũ phải bằng 100%.
    - Phân tích ngắn gọn tình hình của người dùng.
    - Đề xuất tỷ lệ phần trăm MỚI cho mỗi hũ. Ghi rõ sự thay đổi (ví dụ: "NEC: 50% (-5%)").
    - Giải thích LÝ DO cho từng sự điều chỉnh một cách rõ ràng, súc tích.
    - Sử dụng ngôn ngữ tích cực, khuyến khích và dễ hiểu.
    - Trình bày câu trả lời bằng Markdown để dễ đọc, với các tiêu đề và danh sách.`;

    const contents = `Đây là tình hình tài chính của tôi: "${situation}".
    
    Tỷ lệ phân bô hiện tại của tôi là: ${currentAllocation}.
    
    Dựa trên thông tin tôi cung cấp, hãy đưa ra lời khuyên về cách tôi nên điều chỉnh tỷ lệ của mình.`;

    try {
        // Fix: Querying GenAI with both the model and prompt in a single generateContent call.
        const response = await ai.models.generateContent({
            model,
            contents,
            config: {
                systemInstruction,
                temperature: 0.7,
            },
        });
        // Fix: Use the .text property directly from the response object.
        return response.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        throw new Error("Không thể nhận được lời khuyên từ AI. Vui lòng kiểm tra lại cấu hình hoặc thử lại sau.");
    }
}
