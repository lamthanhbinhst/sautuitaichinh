
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import type { AllocatedJar } from '../types';

interface AllocationChartProps {
    jars: AllocatedJar[];
}

// Convert Tailwind bg colors to hex for Recharts
const tailwindToHex: { [key: string]: string } = {
    'bg-sky-500': '#0ea5e9',
    'bg-emerald-500': '#10b981',
    'bg-indigo-500': '#6366f1',
    'bg-amber-500': '#f59e0b',
    'bg-rose-500': '#f43f5e',
    'bg-fuchsia-500': '#d946ef',
};

const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
        const data = payload[0].payload;
        return (
            <div className="bg-white p-2 border border-slate-200 rounded-lg shadow-sm">
                <p className="font-semibold">{`${data.name}`}</p>
                <p className="text-sm text-slate-600">{`Phần trăm: ${data.percentage}%`}</p>
                 <p className="text-sm text-slate-600">{`Phân bổ tháng này: ${data.amountAddedThisMonth.toLocaleString('vi-VN')} VND`}</p>
            </div>
        );
    }
    return null;
};

export const AllocationChart: React.FC<AllocationChartProps> = ({ jars }) => {
    const chartData = jars.filter(jar => jar.percentage > 0);
    
    return (
        <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
                <PieChart>
                    <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        innerRadius={40}
                        fill="#8884d8"
                        dataKey="percentage"
                        nameKey="name"
                        stroke="none"
                    >
                        {chartData.map((entry) => (
                            <Cell key={`cell-${entry.id}`} fill={tailwindToHex[entry.color] || '#cccccc'} />
                        ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend iconType="circle" iconSize={10} />
                </PieChart>
            </ResponsiveContainer>
        </div>
    );
};