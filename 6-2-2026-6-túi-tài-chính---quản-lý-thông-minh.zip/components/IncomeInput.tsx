
import React, { useState, useMemo } from 'react';
import type { Income } from '../types';

interface IncomeInputProps {
    incomes: Income[];
    onAddClick: () => void;
    onEditClick: (income: Income) => void;
    onDeleteClick: (incomeId: string) => void;
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
};

const ChevronDownIcon = (props: React.ComponentProps<'svg'>) => <svg {...props} xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>;
const PlusCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;


export const IncomeInput: React.FC<IncomeInputProps> = ({ incomes, onAddClick, onEditClick, onDeleteClick }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const totalIncome = useMemo(() => {
        return incomes.reduce((sum, income) => sum + income.amount, 0);
    }, [incomes]);

    return (
        <div className="bg-white rounded-xl shadow-md">
            <div 
                className="p-6 cursor-pointer flex justify-between items-center"
                onClick={() => setIsExpanded(!isExpanded)}
                role="button"
                aria-expanded={isExpanded}
            >
                <div className="flex items-baseline space-x-4">
                    <h3 className="font-semibold text-lg text-slate-700">Thu nhập</h3>
                    <span className="font-mono font-bold text-2xl text-indigo-600">
                        {formatCurrency(totalIncome)}
                    </span>
                </div>
                <ChevronDownIcon style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)'}}/>
            </div>

            {isExpanded && (
                <div className="px-6 pb-6 border-t border-slate-200">
                    <div className="mt-4 space-y-3">
                        {incomes.length === 0 ? (
                             <p className="text-center text-slate-500 py-4">Chưa có khoản thu nhập nào được ghi.</p>
                        ) : (
                            <ul className="space-y-2">
                                {incomes.map(income => (
                                    <li key={income.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-lg group">
                                        <div>
                                            <span className="text-slate-700">{income.description}</span>
                                            <span className="block font-mono font-semibold text-emerald-600 sm:hidden">{formatCurrency(income.amount)}</span>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <span className="font-mono font-semibold text-emerald-600 hidden sm:block">{formatCurrency(income.amount)}</span>
                                            <button onClick={() => onEditClick(income)} className="p-2 rounded-full hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-opacity lg:opacity-0 group-hover:opacity-100" aria-label="Sửa thu nhập">
                                                <PencilIcon />
                                            </button>
                                            <button onClick={() => onDeleteClick(income.id)} className="p-2 rounded-full hover:bg-red-200 text-red-500 hover:text-red-700 transition-opacity lg:opacity-0 group-hover:opacity-100" aria-label="Xóa thu nhập">
                                                <TrashIcon />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                    <button
                        onClick={onAddClick}
                        className="w-full mt-4 flex items-center justify-center px-4 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform transform active:scale-95"
                    >
                        <PlusCircleIcon />
                        Thêm thu nhập
                    </button>
                </div>
            )}
        </div>
    );
};
