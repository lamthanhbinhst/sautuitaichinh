

import React, { useState, useEffect } from 'react';
import type { AllocatedJar, Jar, Expense } from '../types';

interface AddExpenseModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: {id?: string, jarId: Jar['id'], amount: number, description: string}) => void;
    expenseToEdit?: Expense | null;
    jarForNewExpense?: AllocatedJar | null;
    jars: AllocatedJar[]; // Needed to find jar details when editing
}

const formatNumber = (numStr: string) => {
    if (!numStr) return '';
    const number = parseInt(numStr.replace(/\./g, ''), 10);
    return isNaN(number) ? '' : number.toLocaleString('vi-VN');
};

export const AddExpenseModal: React.FC<AddExpenseModalProps> = ({ isOpen, onClose, onSave, expenseToEdit, jarForNewExpense, jars }) => {
    const [amount, setAmount] = useState('');
    const [description, setDescription] = useState('');
    const [error, setError] = useState('');

    const isEditMode = !!expenseToEdit;
    const jar = isEditMode 
        ? jars.find(j => j.id === expenseToEdit.jarId) 
        : jarForNewExpense;

    useEffect(() => {
        if (isOpen) {
            if (isEditMode && expenseToEdit) {
                setAmount(String(expenseToEdit.amount));
                setDescription(expenseToEdit.description);
            } else {
                setAmount('');
                setDescription('');
            }
            setError('');
        }
    }, [isOpen, isEditMode, expenseToEdit]);

    if (!isOpen || !jar) return null;

    const handleSave = () => {
        const numericAmount = parseInt(amount.replace(/\./g, ''), 10);

        if (isNaN(numericAmount) || numericAmount < 0) {
            setError('Vui lòng nhập số tiền hợp lệ (lớn hơn hoặc bằng 0).');
            return;
        }
        if (description.trim().length === 0) {
            setError('Vui lòng nhập nội dung chi tiêu.');
            return;
        }

        // Removed balance check to allow overspending
        
        onSave({
            id: isEditMode ? expenseToEdit.id : undefined,
            jarId: jar.id,
            amount: numericAmount, 
            description: description.trim()
        });
        onClose();
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value.replace(/\./g, '');
        if (/^\d*$/.test(value)) {
            setAmount(value);
        }
    };
    
    const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;

    const title = isEditMode ? 'Chỉnh sửa chi tiêu' : `Ghi chi tiêu cho hũ "${jar.name}"`;
    const saveButtonText = isEditMode ? 'Cập nhật' : 'Lưu';

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
                <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                    <h2 className="text-xl font-bold text-slate-800">
                        {title}
                    </h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Đóng">
                        <CloseIcon />
                    </button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label htmlFor="expense-description" className="block text-sm font-medium text-slate-600 mb-1">
                            Nội dung chi tiêu
                        </label>
                        <input
                            id="expense-description"
                            type="text"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            className="w-full p-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                            placeholder="VD: Ăn tối, mua sách..."
                        />
                    </div>
                    <div>
                        <label htmlFor="expense-amount" className="block text-sm font-medium text-slate-600 mb-1">
                            Số tiền
                        </label>
                        <div className="relative">
                           <input
                                id="expense-amount"
                                type="text"
                                value={formatNumber(amount)}
                                onChange={handleAmountChange}
                                className="w-full pl-4 pr-12 py-2 text-md text-right font-mono border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                                placeholder="0"
                            />
                            <span className="absolute top-1/2 right-4 -translate-y-1/2 text-slate-400 font-semibold text-sm">VND</span>
                        </div>
                    </div>
                    {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
                </div>
                <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-6 py-2 bg-slate-200 text-slate-800 font-semibold rounded-md hover:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400">
                        Hủy
                    </button>
                    <button onClick={handleSave} className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        {saveButtonText}
                    </button>
                </div>
            </div>
        </div>
    );
};