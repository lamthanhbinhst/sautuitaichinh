
import React from 'react';
import type { Expense, AllocatedJar } from '../types';

interface ExpenseListProps {
    expenses: Expense[];
    jars: AllocatedJar[];
    onEdit: (expense: Expense) => void;
    onDelete: (expenseId: string) => void;
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
};

const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;

export const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, jars, onEdit, onDelete }) => {
    const getJarDetails = (jarId: string) => {
        return jars.find(j => j.id === jarId);
    };
    
    if(expenses.length === 0) {
        return null;
    }

    return (
        <div className="bg-white rounded-xl shadow-md p-4 md:p-6">
            <h3 className="font-semibold text-lg text-slate-700 mb-4">Lịch sử chi tiêu trong tháng</h3>
            <ul className="space-y-3">
                {expenses.map(expense => {
                    const jar = getJarDetails(expense.jarId);
                    return (
                        <li key={expense.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-lg group">
                            <div className="flex items-center space-x-3">
                                {jar && (
                                    <div className={`w-8 h-8 rounded-full ${jar.color} flex items-center justify-center text-white flex-shrink-0`} title={`Hũ: ${jar.name}`}>
                                        {React.cloneElement(jar.icon, { className: 'h-5 w-5' })}
                                    </div>
                                )}
                                <div>
                                    <p className="font-medium text-slate-800">{expense.description}</p>
                                    <p className="text-sm text-slate-500 sm:hidden">{jar?.name}</p>
                                </div>
                            </div>
                            <div className="flex items-center space-x-2">
                                <div className="text-right">
                                    <p className="font-mono font-semibold text-rose-600">{formatCurrency(expense.amount)}</p>
                                    <p className="text-sm text-slate-500 hidden sm:block">{jar?.name}</p>
                                </div>
                                <button onClick={() => onEdit(expense)} className="p-2 rounded-full hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-opacity lg:opacity-0 group-hover:opacity-100" aria-label="Sửa chi tiêu">
                                    <PencilIcon />
                                </button>
                                <button onClick={() => onDelete(expense.id)} className="p-2 rounded-full hover:bg-red-200 text-red-500 hover:text-red-700 transition-opacity lg:opacity-0 group-hover:opacity-100" aria-label="Xóa chi tiêu">
                                    <TrashIcon />
                                </button>
                            </div>
                        </li>
                    );
                })}
            </ul>
        </div>
    );
};