
import React, { useState, useEffect } from 'react';

interface ShareModalProps {
    isOpen: boolean;
    onClose: () => void;
    shareUrl: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, shareUrl }) => {
    const [isCopied, setIsCopied] = useState(false);
    
    useEffect(() => {
        if (!isOpen) {
            // Reset copy status when modal is closed
            setIsCopied(false);
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleCopy = () => {
        navigator.clipboard.writeText(shareUrl).then(() => {
            setIsCopied(true);
            setTimeout(() => {
                setIsCopied(false);
            }, 2500);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            alert('Không thể sao chép liên kết. Vui lòng thử sao chép thủ công.');
        });
    };
    
    const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;
    const CopyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
    const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
            <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full">
                <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                    <h2 className="text-xl font-bold text-slate-800">
                        Chia sẻ kế hoạch tài chính
                    </h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Đóng">
                        <CloseIcon />
                    </button>
                </div>
                <div className="p-6 space-y-4">
                    <p className="text-sm text-slate-600">
                        Thao tác này sẽ tạo một liên kết duy nhất chứa **bản sao** dữ liệu hiện tại của bạn. Người nhận có thể mở liên kết này để xem và sử dụng kế hoạch của bạn làm điểm khởi đầu cho riêng họ.
                    </p>
                    <p className="text-sm font-medium text-slate-700 bg-yellow-50 border-l-4 border-yellow-400 p-3 rounded-r-lg">
                        Lưu ý: Mọi thay đổi của người nhận sẽ <span className="font-bold">không</span> ảnh hưởng đến dữ liệu gốc của bạn.
                    </p>
                     <div>
                        <label htmlFor="share-url" className="block text-sm font-medium text-slate-600 mb-1">
                            Liên kết chia sẻ
                        </label>
                        <div className="flex items-center">
                             <input
                                id="share-url"
                                type="text"
                                value={shareUrl}
                                readOnly
                                className="w-full p-2 border border-slate-300 bg-slate-50 rounded-lg text-sm text-slate-600 mr-2"
                                onFocus={(e) => e.target.select()}
                            />
                            <button 
                                onClick={handleCopy}
                                className={`flex-shrink-0 flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md transition-colors ${isCopied 
                                    ? 'bg-emerald-600 text-white' 
                                    : 'bg-indigo-600 text-white hover:bg-indigo-700'}`
                                }
                                disabled={isCopied}
                            >
                                {isCopied ? <CheckIcon/> : <CopyIcon/>}
                                {isCopied ? 'Đã sao chép' : 'Sao chép'}
                            </button>
                        </div>
                    </div>
                </div>
                <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end">
                    <button onClick={onClose} className="px-6 py-2 bg-slate-200 text-slate-800 font-semibold rounded-md hover:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400">
                        Đóng
                    </button>
                </div>
            </div>
        </div>
    );
};