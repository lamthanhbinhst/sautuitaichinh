
import React, { useMemo } from 'react';
import type { MonthlyRecord, AllocatedJar, Jar } from '../types';
import { DEFAULT_JARS } from '../constants';

interface MonthlyReportProps {
    history: MonthlyRecord[];
    calculatedJarBalances: { [month:string]: AllocatedJar[] };
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
};

const formatMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    return `T${month}/${year}`;
}

const headerMapping: Record<Jar['id'], string> = {
    'NEC': 'Thiết yếu',
    'FFA': 'Tự do TC',
    'LTS': 'Dài hạn',
    'EDU': 'Giáo dục',
    'PLAY': 'Hưởng thụ',
    'GIVE': 'Cho đi',
};


export const MonthlyReport: React.FC<MonthlyReportProps> = ({ history, calculatedJarBalances }) => {
    const sortedHistory = [...history].sort((a, b) => a.month.localeCompare(b.month));
    const jarOrder = DEFAULT_JARS.map(j => j.id);

    const totals = useMemo(() => {
        let totalIncomeAllMonths = 0;
        let totalExpensesAllMonths = 0;
        const totalJarAllocations = jarOrder.reduce((acc, jarId) => ({ ...acc, [jarId]: 0 }), {} as Record<Jar['id'], number>);
        const totalJarSpends = jarOrder.reduce((acc, jarId) => ({ ...acc, [jarId]: 0 }), {} as Record<Jar['id'], number>);

        for (const record of sortedHistory) {
            totalIncomeAllMonths += (record.incomes || []).reduce((sum, income) => sum + income.amount, 0);
            totalExpensesAllMonths += (record.expenses || []).reduce((sum, exp) => sum + exp.amount, 0);

            const monthBalances = calculatedJarBalances[record.month] || [];
            for (const balance of monthBalances) {
                if (totalJarAllocations.hasOwnProperty(balance.id)) {
                    totalJarAllocations[balance.id] += balance.amountAddedThisMonth;
                    totalJarSpends[balance.id] += balance.amountSpentThisMonth;
                }
            }
        }

        return { totalIncomeAllMonths, totalExpensesAllMonths, totalJarAllocations, totalJarSpends };
    }, [sortedHistory, calculatedJarBalances, jarOrder]);


    return (
        <div className="bg-white p-2 md:p-6 rounded-xl shadow-md mt-6 md:mt-8">
            <h2 className="text-xl font-bold text-slate-800 mb-4 px-2 md:px-0">Báo cáo tổng hợp các tháng</h2>
            <div className="overflow-x-auto">
                <table className="w-full text-left text-slate-600">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-100 rounded-t-lg">
                        <tr>
                            <th scope="col" className="px-2 sm:px-3 md:px-4 py-3 font-semibold">Tháng</th>
                            <th scope="col" className="px-2 sm:px-3 md:px-4 py-3 font-semibold text-right text-emerald-700">Tổng còn lại</th>
                            {DEFAULT_JARS.map(jar => (
                                <th key={jar.id} scope="col" className="px-2 sm:px-3 md:px-4 py-3 font-semibold text-center">{headerMapping[jar.id]}</th>
                            ))}
                            <th scope="col" className="px-2 sm:px-3 md:px-4 py-3 font-semibold text-right">Tổng thu nhập</th>
                            <th scope="col" className="px-2 sm:px-3 md:px-4 py-3 font-semibold text-right">Tổng chi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedHistory.map(record => {
                            const totalIncome = (record.incomes || []).reduce((sum, income) => sum + income.amount, 0);
                            const totalExpenses = (record.expenses || []).reduce((sum, exp) => sum + exp.amount, 0);
                            const totalRemaining = totalIncome - totalExpenses;
                            const monthBalances = calculatedJarBalances[record.month] || [];
                            
                            // Fix: Explicitly type the Map constructor to ensure the compiler correctly infers 'balance' as AllocatedJar | undefined
                            const balancesMap = new Map<Jar['id'], AllocatedJar>(monthBalances.map(b => [b.id, b]));

                            return (
                                <tr key={record.month} className="bg-white border-b hover:bg-slate-50">
                                    <th scope="row" className="px-2 sm:px-3 md:px-4 py-4 font-medium text-slate-900 whitespace-nowrap text-xs sm:text-sm">
                                        {formatMonth(record.month)}
                                    </th>
                                    <td className="px-2 sm:px-3 md:px-4 py-4 text-right font-mono font-bold text-emerald-700 text-xs sm:text-sm">
                                        {formatCurrency(totalRemaining)}
                                    </td>
                                    {jarOrder.map(jarId => {
                                        const balance = balancesMap.get(jarId);
                                        const allocated = (balance && balance.amountAddedThisMonth) || 0;
                                        const spent = (balance && balance.amountSpentThisMonth) || 0;
                                        const finalBalance = (balance && balance.amount) || 0;
                                        return (
                                            <td key={jarId} className="px-2 sm:px-3 md:px-4 py-4 text-right font-mono text-xs sm:text-sm">
                                                <div title="Phân bổ trong tháng">{formatCurrency(allocated)}</div>
                                                {spent > 0 && (
                                                    <div className="text-[11px] sm:text-xs text-rose-600" title="Chi tiêu trong tháng">
                                                        (-{formatCurrency(spent)})
                                                    </div>
                                                )}
                                                <div className="border-t border-slate-200 mt-1 pt-1 font-semibold text-slate-800" title="Số dư cuối tháng">
                                                    {formatCurrency(finalBalance)}
                                                </div>
                                            </td>
                                        )
                                    })}
                                    <td className="px-2 sm:px-3 md:px-4 py-4 text-right font-mono font-semibold text-indigo-600 text-xs sm:text-sm">
                                        {formatCurrency(totalIncome)}
                                    </td>
                                    <td className="px-2 sm:px-3 md:px-4 py-4 text-right font-mono font-semibold text-rose-600 text-xs sm:text-sm">
                                        {formatCurrency(totalExpenses)}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                    <tfoot className="bg-slate-100 border-t-2 border-slate-200">
                        <tr className="font-bold text-slate-800">
                            <th scope="row" className="px-2 sm:px-3 md:px-4 py-3 text-sm sm:text-base text-left">Tổng cộng</th>
                            <td className="px-2 sm:px-3 md:px-4 py-3 text-right font-mono text-emerald-700 text-xs sm:text-sm">{formatCurrency(totals.totalIncomeAllMonths - totals.totalExpensesAllMonths)}</td>
                             {jarOrder.map(jarId => {
                                const totalAllocated = totals.totalJarAllocations[jarId] || 0;
                                const totalSpent = totals.totalJarSpends[jarId] || 0;
                                const netTotal = totalAllocated - totalSpent;
                                return (
                                    <td key={jarId} className="px-2 sm:px-3 md:px-4 py-3 text-right font-mono text-xs sm:text-sm">
                                        <div title="Tổng phân bổ">{formatCurrency(totalAllocated)}</div>
                                        {totalSpent > 0 && (
                                             <div className="text-[11px] sm:text-xs text-rose-700 font-semibold" title="Tổng chi tiêu">
                                                (-{formatCurrency(totalSpent)})
                                            </div>
                                        )}
                                        <div className="border-t border-slate-300 mt-1 pt-1 font-bold text-slate-900" title="Tổng còn lại">
                                            {formatCurrency(netTotal)}
                                        </div>
                                    </td>
                                )
                            })}
                            <td className="px-2 sm:px-3 md:px-4 py-3 text-right font-mono text-indigo-700 text-xs sm:text-sm">{formatCurrency(totals.totalIncomeAllMonths)}</td>
                            <td className="px-2 sm:px-3 md:px-4 py-3 text-right font-mono text-rose-700 text-xs sm:text-sm">{formatCurrency(totals.totalExpensesAllMonths)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};
