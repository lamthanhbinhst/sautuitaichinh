import React from 'react';
import type { AllocatedJar, Jar } from '../types';

// Define soothing, contrasting color schemes for each jar
const colorSchemes: Record<Jar['id'], { bg: string; iconBg: string; text: string; button: string; buttonHover: string; }> = {
    'NEC': { bg: 'bg-sky-50', iconBg: 'bg-sky-500', text: 'text-sky-900', button: 'bg-sky-200', buttonHover: 'hover:bg-sky-300' },
    'FFA': { bg: 'bg-emerald-50', iconBg: 'bg-emerald-500', text: 'text-emerald-900', button: 'bg-emerald-200', buttonHover: 'hover:bg-emerald-300' },
    'LTS': { bg: 'bg-indigo-50', iconBg: 'bg-indigo-500', text: 'text-indigo-900', button: 'bg-indigo-200', buttonHover: 'hover:bg-indigo-300' },
    'EDU': { bg: 'bg-amber-50', iconBg: 'bg-amber-500', text: 'text-amber-900', button: 'bg-amber-200', buttonHover: 'hover:bg-amber-300' },
    'PLAY': { bg: 'bg-rose-50', iconBg: 'bg-rose-500', text: 'text-rose-900', button: 'bg-rose-200', buttonHover: 'hover:bg-rose-300' },
    'GIVE': { bg: 'bg-fuchsia-50', iconBg: 'bg-fuchsia-500', text: 'text-fuchsia-900', button: 'bg-fuchsia-200', buttonHover: 'hover:bg-fuchsia-300' },
};

interface JarCardProps {
    jar: AllocatedJar;
    onPercentageChange: (id: Jar['id'], newPercentage: number) => void;
    onAddExpenseClick: () => void;
}

export const JarCard: React.FC<JarCardProps> = ({ jar, onPercentageChange, onAddExpenseClick }) => {
    const handlePercentageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = parseInt(e.target.value, 10);
        if (!isNaN(value) && value >= 0 && value <= 100) {
            onPercentageChange(jar.id, value);
        } else if (e.target.value === '') {
            onPercentageChange(jar.id, 0);
        }
    };
    
    const formatCurrency = (value: number) => {
        return value.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
    };

    const colors = colorSchemes[jar.id];

    return (
        <div className={`p-4 rounded-xl ${colors.bg} ${colors.text} flex flex-col justify-between shadow-sm h-full`}>
            {/* Main content area */}
            <div>
                {/* Row 1: Icon, Name, and Description */}
                <div className="flex items-start gap-3 mb-4">
                    <div className={`w-10 h-10 rounded-lg ${colors.iconBg} flex items-center justify-center text-white flex-shrink-0`}>
                        {React.cloneElement(jar.icon, { className: "h-6 w-6" })}
                    </div>
                    <div className="flex-grow overflow-hidden">
                        <h3 className="font-bold text-base" title={jar.name}>{jar.name}</h3>
                        <p className="text-xs text-slate-500 truncate" title={jar.description}>{jar.description}</p>
                    </div>
                </div>

                {/* Row 2: Percentage and Balance */}
                <div className="space-y-2">
                    <div className="flex justify-between items-center gap-4">
                        <div className="flex items-center gap-1 bg-white rounded-lg border border-slate-200 p-1 shadow-sm">
                            <input
                                type="number"
                                value={jar.percentage}
                                onChange={handlePercentageChange}
                                className="w-12 text-right font-bold text-lg bg-transparent focus:outline-none"
                                aria-label={`Percentage for ${jar.name}`}
                            />
                            <span className="text-lg font-bold text-slate-500">%</span>
                        </div>
                        <div className="text-right">
                            <p className="text-xl font-mono font-bold" title={`Số dư cuối kỳ`}>
                                {formatCurrency(jar.amount)}
                            </p>
                            <div className="flex justify-end items-baseline gap-3 text-xs font-mono mt-0.5">
                                <p className="text-emerald-600" title="Số tiền thêm vào trong tháng này">
                                    +{formatCurrency(jar.amountAddedThisMonth)}
                                </p>
                                <p className="text-rose-600" title="Số tiền đã chi trong tháng này">
                                    -{formatCurrency(jar.amountSpentThisMonth)}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Section: Action Button */}
            <div className="mt-4">
                <button
                    onClick={onAddExpenseClick}
                    className={`w-full text-sm font-semibold py-2.5 px-3 rounded-lg ${colors.button} ${colors.text} ${colors.buttonHover} transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
                >
                    Ghi Chi Tiêu
                </button>
            </div>
        </div>
    );
};
