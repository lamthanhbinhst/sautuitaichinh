
import React, { useRef, useState } from 'react';
import type { MonthlyRecord } from '../types';

interface BackupModalProps {
    isOpen: boolean;
    onClose: () => void;
    history: MonthlyRecord[];
    userName: string;
    onRestore: (data: { history: MonthlyRecord[], userName: string }) => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose, history, userName, onRestore }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [importError, setImportError] = useState('');

    if (!isOpen) return null;

    const handleExport = () => {
        const data = {
            version: "1.0",
            exportDate: new Date().toISOString(),
            userName,
            history
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `sau-tui-backup-${userName || 'user'}-${new Date().toISOString().slice(0,10)}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setImportError('');
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const json = JSON.parse(e.target?.result as string);
                if (!json.history || !Array.isArray(json.history)) {
                    throw new Error("Định dạng tệp không hợp lệ.");
                }

                if (window.confirm("CẢNH BÁO: Việc khôi phục sẽ ghi đè toàn bộ dữ liệu hiện tại trên máy này. Bạn có chắc chắn muốn tiếp tục?")) {
                    onRestore({
                        history: json.history,
                        userName: json.userName || ''
                    });
                    onClose();
                    alert("Khôi phục dữ liệu thành công!");
                }
            } catch (err) {
                setImportError("Lỗi: Tệp tin không đúng định dạng hoặc bị hỏng.");
            }
        };
        reader.readAsText(file);
        // Reset input to allow selecting the same file again if needed
        event.target.value = '';
    };

    const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;
    const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>;
    const UploadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                    <div>
                        <h2 className="text-xl font-bold text-slate-800">Sao lưu & Khôi phục</h2>
                        <p className="text-xs text-slate-500">Chuyển dữ liệu sang thiết bị mới</p>
                    </div>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1" aria-label="Đóng">
                        <CloseIcon />
                    </button>
                </div>
                
                <div className="p-6 space-y-6">
                    <section>
                        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Bước 1: Trên máy cũ</h3>
                        <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                            Tải tệp dữ liệu của bạn về máy. Bạn có thể gửi tệp này qua Zalo, Email hoặc Google Drive sang thiết bị mới.
                        </p>
                        <button 
                            onClick={handleExport}
                            className="w-full flex items-center justify-center px-4 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
                        >
                            <DownloadIcon />
                            Xuất tệp dữ liệu (.json)
                        </button>
                    </section>

                    <div className="border-t border-slate-100"></div>

                    <section>
                        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Bước 2: Trên máy mới</h3>
                        <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                            Chọn tệp dữ liệu đã tải từ máy cũ để khôi phục toàn bộ lịch sử chi tiêu.
                        </p>
                        <button 
                            onClick={handleImportClick}
                            className="w-full flex items-center justify-center px-4 py-3 bg-white border-2 border-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
                        >
                            <UploadIcon />
                            Nhập tệp dữ liệu
                        </button>
                        <input 
                            type="file" 
                            ref={fileInputRef} 
                            onChange={handleFileChange} 
                            accept=".json" 
                            className="hidden" 
                        />
                        {importError && (
                            <p className="text-red-500 text-xs mt-2 font-medium bg-red-50 p-2 rounded border border-red-100 italic">
                                {importError}
                            </p>
                        )}
                    </section>
                </div>

                <div className="bg-amber-50 p-4 border-t border-amber-100">
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                        <strong>Lưu ý:</strong> Dữ liệu chỉ được lưu trên trình duyệt của bạn. Hãy thường xuyên sao lưu để tránh mất mát khi xóa lịch sử web hoặc đổi điện thoại.
                    </p>
                </div>
            </div>
        </div>
    );
};
