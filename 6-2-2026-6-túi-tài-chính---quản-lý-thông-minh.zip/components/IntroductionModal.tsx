
import React from 'react';
import { DEFAULT_JARS } from '../constants';

interface IntroductionModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const IntroductionModal: React.FC<IntroductionModalProps> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;
    
    const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div 
                className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
                role="dialog"
                aria-modal="true"
                aria-labelledby="modal-title"
            >
                <div className="sticky top-0 bg-white p-6 border-b border-slate-200 flex justify-between items-center">
                    <h2 id="modal-title" className="text-2xl font-bold text-slate-800">Phương pháp 6 Túi Tài Chính</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Đóng">
                       <CloseIcon />
                    </button>
                </div>
                <div className="p-6 space-y-6">
                    <div>
                        <h3 className="text-lg font-semibold text-slate-700 mb-2">6 Túi Tài Chính là gì?</h3>
                        <p className="text-slate-600">
                            Đây là một phương pháp quản lý tài chính cá nhân đơn giản và hiệu quả, được tạo ra bởi T. Harv Eker. Mục tiêu là chia thu nhập hàng tháng của bạn vào 6 "túi" (hay "hũ") ảo khác nhau, mỗi túi phục vụ một mục đích riêng. Điều này giúp bạn kiểm soát chi tiêu, đảm bảo các khía cạnh quan trọng của cuộc sống đều được quan tâm về mặt tài chính.
                        </p>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-700 mb-4">Các túi và tỷ lệ đề xuất</h3>
                        <div className="space-y-4">
                            {DEFAULT_JARS.map(jar => (
                                <div key={jar.id} className="flex items-start">
                                    <div className={`w-12 h-12 rounded-lg ${jar.color} flex items-center justify-center text-white mr-4 flex-shrink-0`}>
                                        {jar.icon}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-slate-800">{jar.name} ({jar.percentage}%)</h4>
                                        <p className="text-sm text-slate-500">{jar.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-700 mb-2">Tại sao nên áp dụng?</h3>
                        <ul className="list-disc list-inside text-slate-600 space-y-1">
                            <li><span className="font-semibold">Đơn giản:</span> Dễ hiểu và dễ bắt đầu ngay lập tức.</li>
                            <li><span className="font-semibold">Toàn diện:</span> Cân bằng giữa nhu cầu hiện tại và mục tiêu tương lai.</li>
                            <li><span className="font-semibold">Tạo thói quen tốt:</span> Giúp bạn chi tiêu có ý thức và kỷ luật.</li>
                            <li><span className="font-semibold">Linh hoạt:</span> Bạn có thể điều chỉnh tỷ lệ cho phù hợp với từng giai đoạn cuộc đời.</li>
                        </ul>
                    </div>
                </div>
                 <div className="sticky bottom-0 bg-slate-50 p-4 border-t border-slate-200 text-right">
                    <button onClick={onClose} className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Đã hiểu
                    </button>
                </div>
            </div>
        </div>
    );
};
