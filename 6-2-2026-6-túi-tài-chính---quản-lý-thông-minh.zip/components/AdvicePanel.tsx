
import React, { useState } from 'react';
import { marked } from 'marked';

interface AdvicePanelProps {
    onFetchAdvice: (situation: string) => Promise<void>;
    aiAdvice: string;
    isLoading: boolean;
    error: string;
}

const LoadingSpinner = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
);

export const AdvicePanel: React.FC<AdvicePanelProps> = ({ onFetchAdvice, aiAdvice, isLoading, error }) => {
    const [situation, setSituation] = useState('');
    const [promptError, setPromptError] = useState('');

    const handleSubmit = () => {
        if (situation.trim().length < 10) {
            setPromptError('Vui lòng mô tả tình hình của bạn chi tiết hơn (ít nhất 10 ký tự).');
            return;
        }
        setPromptError('');
        onFetchAdvice(situation);
    };

    const parsedAdvice = aiAdvice ? marked.parse(aiAdvice) : '';

    return (
        <div className="space-y-4">
            <p className="text-sm text-slate-600">
                Mô tả tình hình tài chính của bạn (ví dụ: "Tôi mới đi làm, lương thấp và đang có một khoản nợ nhỏ") để AI đưa ra gợi ý điều chỉnh tỷ lệ.
            </p>
            <div>
                <textarea
                    value={situation}
                    onChange={(e) => setSituation(e.target.value)}
                    className="w-full p-3 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    rows={3}
                    placeholder="Mô tả tình hình của bạn ở đây..."
                    disabled={isLoading}
                />
                {promptError && <p className="text-red-500 text-sm mt-1">{promptError}</p>}
            </div>
            <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="w-full px-6 py-3 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all flex items-center justify-center"
            >
                {isLoading ? 'Đang phân tích...' : 'Nhận lời khuyên'}
            </button>
            
            <div className="mt-4 min-h-[100px]">
                {isLoading && <LoadingSpinner />}
                {error && <p className="text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
                {aiAdvice && (
                    <div 
                        className="prose prose-sm max-w-none prose-headings:font-bold prose-headings:text-slate-800 prose-p:text-slate-700 prose-li:text-slate-600"
                        dangerouslySetInnerHTML={{ __html: parsedAdvice as string }} 
                    />
                )}
            </div>
        </div>
    );
};
