
import React from 'react';
import type { AllocatedJar, Jar } from '../types';
import { JarCard } from './JarCard';

interface JarsDisplayProps {
    jars: AllocatedJar[];
    onPercentageChange: (id: Jar['id'], newPercentage: number) => void;
    totalPercentage: number;
    onOpenAddExpenseModal: (jar: AllocatedJar) => void;
}

const WarningIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
);


export const JarsDisplay: React.FC<JarsDisplayProps> = ({ jars, onPercentageChange, totalPercentage, onOpenAddExpenseModal }) => {
    const isTotal100 = totalPercentage === 100;

    return (
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-slate-800">Phân bổ thu nhập</h2>
                <div className={`px-3 py-1 text-sm font-bold rounded-full ${isTotal100 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                    Tổng: {totalPercentage}%
                </div>
            </div>
             {!isTotal100 && (
                <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-4 rounded-r-lg flex items-center gap-3">
                    <WarningIcon />
                    <div>
                         <p className="font-bold text-amber-800">Tổng tỷ lệ chưa bằng 100%!</p>
                         <p className="text-sm text-amber-700">Hãy điều chỉnh các hũ để tổng tỷ lệ chính xác là 100%.</p>
                    </div>
                </div>
            )}
            <div className="flex flex-wrap -m-2">
                {jars.map(jar => (
                    <div key={jar.id} className="w-full md:w-1/2 lg:w-1/3 p-2">
                        <JarCard
                            jar={jar}
                            onPercentageChange={onPercentageChange}
                            onAddExpenseClick={() => onOpenAddExpenseModal(jar)}
                        />
                    </div>
                ))}
            </div>
        </div>
    );
};