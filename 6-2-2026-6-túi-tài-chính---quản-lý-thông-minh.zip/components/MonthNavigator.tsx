
import React from 'react';

interface MonthNavigatorProps {
    selectedMonth: string;
    availableMonths: string[];
    onMonthChange: (month: string) => void;
    onAddNewMonth: () => void;
}

const formatMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    return `Tháng ${month}, ${year}`;
}

export const MonthNavigator: React.FC<MonthNavigatorProps> = ({
    selectedMonth,
    availableMonths,
    onMonthChange,
    onAddNewMonth
}) => {
    const currentIndex = availableMonths.indexOf(selectedMonth);
    const canGoBack = currentIndex > 0;
    const canGoForward = currentIndex < availableMonths.length - 1;

    const handlePrevious = () => {
        if (canGoBack) {
            onMonthChange(availableMonths[currentIndex - 1]);
        }
    };

    const handleNext = () => {
        if (canGoForward) {
            onMonthChange(availableMonths[currentIndex + 1]);
        }
    };
    
    const isLatestMonth = currentIndex === availableMonths.length - 1;

    const ChevronLeftIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>;
    const ChevronRightIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>;
    const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>;

    return (
        <div className="bg-white p-4 rounded-xl shadow-md flex items-center justify-between">
            <div className="flex items-center space-x-2">
                <button 
                    onClick={handlePrevious} 
                    disabled={!canGoBack}
                    className="p-2 rounded-full hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    aria-label="Tháng trước"
                >
                    <ChevronLeftIcon />
                </button>
                <span className="font-semibold text-base text-slate-700 w-36 text-center">{formatMonth(selectedMonth)}</span>
                <button 
                    onClick={handleNext} 
                    disabled={!canGoForward}
                    className="p-2 rounded-full hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    aria-label="Tháng sau"
                >
                    <ChevronRightIcon />
                </button>
            </div>
            {isLatestMonth && (
                 <button
                    onClick={onAddNewMonth}
                    className="flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-emerald-700 bg-emerald-100 hover:bg-emerald-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
                >
                    <PlusIcon/>
                    <span className="hidden sm:inline">Thêm tháng mới</span>
                    <span className="sm:hidden">Thêm</span>
                </button>
            )}
        </div>
    );
};
