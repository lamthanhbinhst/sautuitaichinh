
import React from 'react';
import { AdvicePanel } from './AdvicePanel';

interface DashboardProps {
    onFetchAdvice: (situation: string) => Promise<void>;
    aiAdvice: string;
    isLoading: boolean;
    error: string;
}

export const Dashboard: React.FC<DashboardProps> = ({ onFetchAdvice, aiAdvice, isLoading, error }) => {
    return (
        <div className="space-y-6 md:space-y-8">
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
                <h2 className="text-xl font-bold text-slate-800 mb-4">Tư vấn từ AI</h2>
                <AdvicePanel 
                    onFetchAdvice={onFetchAdvice}
                    aiAdvice={aiAdvice}
                    isLoading={isLoading}
                    error={error}
                />
            </div>
        </div>
    );
};