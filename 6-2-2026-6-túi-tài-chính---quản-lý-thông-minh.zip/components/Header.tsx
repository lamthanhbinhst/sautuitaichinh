
import React from 'react';

interface HeaderProps {
    onIntroClick: () => void;
    onShareClick: () => void;
    onBackupClick: () => void;
    appVersion: string;
    userName: string;
    onUserNameChange: (name: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onIntroClick, onShareClick, onBackupClick, appVersion, userName, onUserNameChange }) => {
    const BookOpenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
    const ShareIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
    const CloudIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v8" /></svg>;

    return (
        <header className="bg-white shadow-sm sticky top-0 z-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex-grow">
                        <div className="flex items-baseline">
                            <h1 className="text-lg md:text-xl font-bold text-slate-800 shrink-0">
                                <span className="text-indigo-600">6 Túi</span> Tài Chính của&nbsp;
                            </h1>
                            <input
                                type="text"
                                value={userName}
                                onChange={(e) => onUserNameChange(e.target.value)}
                                placeholder="..."
                                className="font-bold text-lg md:text-xl text-indigo-600 bg-transparent border-b-2 border-dotted border-slate-400 focus:border-solid focus:border-indigo-500 focus:outline-none w-full max-w-[120px] md:max-w-[200px] p-0"
                                aria-label="Tên người sử dụng"
                            />
                        </div>
                        <p className="text-[10px] text-slate-500">v{appVersion}</p>
                    </div>
                    <div className="flex items-center space-x-1 md:space-x-2">
                        <button
                            onClick={onBackupClick}
                            className="flex items-center justify-center p-2 sm:px-3 sm:py-2 border border-slate-200 text-sm font-medium rounded-md text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                            title="Sao lưu & Khôi phục"
                        >
                            <CloudIcon />
                            <span className="hidden lg:inline">Sao lưu</span>
                        </button>
                        <button
                            onClick={onShareClick}
                            className="flex items-center justify-center p-2 sm:px-3 sm:py-2 border border-slate-200 text-sm font-medium rounded-md text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                            title="Chia sẻ kế hoạch"
                        >
                            <ShareIcon />
                            <span className="hidden md:inline">Chia sẻ</span>
                        </button>
                        <button
                            onClick={onIntroClick}
                            className="flex items-center justify-center p-2 sm:px-3 sm:py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-50 hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                        >
                            <BookOpenIcon />
                            <span className="hidden md:inline">Lý thuyết</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};
